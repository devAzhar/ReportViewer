import 'dotenv/config';
import { get } from 'lodash';
import { TestMe, hello } from '../dist/lib';

console.log('Hello Node.js project.');
console.log(process.env.MY_SECRET);
console.log(get(process.env, 'MY_SECRET', null));

console.log(hello(`Test Call ${process.env.MY_SECRET}`));
console.log(TestMe(`Test Call ${process.env.MY_SECRET}`));
