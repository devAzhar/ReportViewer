export function hello (word: string = 'test'): string {
    return `Hello ${word}!`;
}

export const TestMe = (msg: string) => {
    if (msg) {
        console.log(`TS -> ${msg}`);
    }

    return new Date();
};
